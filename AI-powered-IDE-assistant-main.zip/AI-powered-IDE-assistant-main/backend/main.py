from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from transformers import AutoModelForMaskedLM, AutoTokenizer
import torch

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

print("Loading CodeBERT model...")
tokenizer = AutoTokenizer.from_pretrained("microsoft/codebert-base")
model = AutoModelForMaskedLM.from_pretrained("microsoft/codebert-base")
print("Model loaded successfully.")


class CodeRequest(BaseModel):
    code: str


def detect_rule_based_completion(code: str) -> str | None:
    normalized_code = code.strip()
    lowered_code = normalized_code.lower()

    if "for" in lowered_code:
        return "for(int i = 0; i < n; i++)"

    if "num %" in normalized_code:
        return "if(num % i == 0) {\n    return false;\n}"

    if "main" in lowered_code:
        return "public static void main(String[] args)"

    if "system.out" in lowered_code:
        return "System.out.println();"

    return None


def generate_model_completion(code: str) -> str:
    masked_code = f"{code.rstrip()} {tokenizer.mask_token}"
    inputs = tokenizer(masked_code, return_tensors="pt")

    with torch.no_grad():
        outputs = model(**inputs)

    logits = outputs.logits
    mask_index = torch.where(inputs["input_ids"] == tokenizer.mask_token_id)[1]
    predicted_token_id = logits[0, mask_index].argmax(axis=-1)
    predicted_token = tokenizer.decode(predicted_token_id).strip()

    return predicted_token if predicted_token else ""


@app.get("/")
def root():
    return {"message": "AI IDE Assistant Backend Running"}


@app.post("/complete")
def complete_code(request: CodeRequest):
    code = request.code

    rule_match = detect_rule_based_completion(code)
    if rule_match:
        return {
            "completion": rule_match,
            "source": "rule"
        }

    return {
        "completion": generate_model_completion(code),
        "source": "model"
    }


@app.post("/explain")
def explain_code(request: CodeRequest):
    code = request.code
    prompt = f"Explain the following Java code in simple terms:\n{code}"
    inputs = tokenizer(prompt, return_tensors="pt")

    with torch.no_grad():
        outputs = model(**inputs)

    predicted_ids = torch.argmax(outputs.logits, dim=-1)
    explanation = tokenizer.decode(predicted_ids[0], skip_special_tokens=True)

    return {"explanation": explanation}


@app.post("/comment")
def generate_comment(request: CodeRequest):
    code = request.code.strip()

    if "num %" in code:
        return {"comment": "// checks divisibility (prime logic)"}

    if "charAt(i)" in code and "n-i-1" in code:
        return {"comment": "// comparing characters for palindrome"}

    if "i <=" in code and "num / 2" in code:
        return {"comment": "// loop to check factors"}

    if "==" in code:
        return {"comment": "// checks equality condition"}

    return {"comment": ""}
