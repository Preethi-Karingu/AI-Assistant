declare module 'node-fetch' {
	type FetchInit = {
		method?: string;
		headers?: Record<string, string>;
		body?: string;
	};

	type FetchResponse = {
		ok: boolean;
		status: number;
		json(): Promise<unknown>;
	};

	export default function fetch(url: string, init?: FetchInit): Promise<FetchResponse>;
}
