import * as vscode from 'vscode';

const COMMENT_API_URL = 'http://127.0.0.1:8000/comment';
const COMPLETE_API_URL = 'http://127.0.0.1:8000/complete';
const ADD_COMMENT_COMMAND = 'new-extension--typescript-.addComment';
const EXPLAIN_CODE_COMMAND = 'new-extension--typescript-.explainCode';

type CommentResponse = {
	comment?: string;
};

type CompletionResponse = {
	completion?: string;
	source?: string;
};

async function postCommentRequest(code: string): Promise<CommentResponse> {
	const { default: fetch } = await import('node-fetch');

	const response = await fetch(COMMENT_API_URL, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json'
		},
		body: JSON.stringify({ code })
	});

	if (!response.ok) {
		throw new Error(`Backend returned ${response.status}`);
	}

	return (await response.json()) as CommentResponse;
}

async function postCompletionRequest(code: string): Promise<CompletionResponse> {
	const { default: fetch } = await import('node-fetch');

	const response = await fetch(COMPLETE_API_URL, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json'
		},
		body: JSON.stringify({ code })
	});

	if (!response.ok) {
		throw new Error(`Backend returned ${response.status}`);
	}

	return (await response.json()) as CompletionResponse;
}

export function activate(context: vscode.ExtensionContext) {
	const explainCmd = vscode.commands.registerCommand(
		EXPLAIN_CODE_COMMAND,
		async () => {
			const editor = vscode.window.activeTextEditor;
			if (!editor) {
				vscode.window.showErrorMessage('No editor open');
				return;
			}

			const selection = editor.selection;
			const selectedText = editor.document.getText(selection);

			if (!selectedText) {
				vscode.window.showErrorMessage('Select code first');
				return;
			}

			try {
				const { default: fetch } = await import('node-fetch');

				console.log('Sending request to backend...');

				const response = await fetch('http://127.0.0.1:8000/explain', {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({ code: selectedText })
				});

				console.log('Response received');

				const data = (await response.json()) as { explanation?: string };

				console.log('Data:', data);

				vscode.window.showInformationMessage(data.explanation ?? 'No explanation returned');
			} catch (error) {
				console.error(error);
				vscode.window.showErrorMessage('Error connecting to backend');
			}
		}
	);

	const addCommentCommand = vscode.commands.registerCommand(ADD_COMMENT_COMMAND, async () => {
		const editor = vscode.window.activeTextEditor;

		if (!editor) {
			vscode.window.showErrorMessage('No active editor found.');
			return;
		}

		const selection = editor.selection;
		if (selection.isEmpty) {
			vscode.window.showErrorMessage('Select code first.');
			return;
		}

		const selectedText = editor.document.getText(selection).trim();
		if (!selectedText) {
			vscode.window.showErrorMessage('Selected text is empty.');
			return;
		}

		try {
			const data = await postCommentRequest(selectedText);
			const comment = data.comment?.trim();

			if (!comment) {
				vscode.window.showErrorMessage('Backend did not return a comment.');
				return;
			}

			const targetLine = editor.document.lineAt(selection.start.line);

			await editor.edit((editBuilder) => {
				editBuilder.insert(targetLine.range.end, ` ${comment}`);
			});
		} catch (error) {
			console.error('Add Comment failed:', error);
			vscode.window.showErrorMessage('Could not reach the comment backend at http://127.0.0.1:8000/comment.');
		}
	});

	const completionProvider = vscode.languages.registerCompletionItemProvider(
		{ language: 'java', scheme: 'file' },
		{
			async provideCompletionItems(document, position) {
				const range = new vscode.Range(new vscode.Position(0, 0), position);
				const codeBeforeCursor = document.getText(range).trim();

				if (!codeBeforeCursor) {
					return [];
				}

				try {
					const data = await postCompletionRequest(codeBeforeCursor);
					const completion = data.completion?.trim();

					if (!completion) {
						return [];
					}

					const item = new vscode.CompletionItem(
						'AI Suggestion',
						vscode.CompletionItemKind.Snippet
					);

					item.insertText = new vscode.SnippetString(completion);
					item.detail = data.source === 'rule' ? 'Rule-based suggestion' : 'AI fallback suggestion';
					item.documentation = new vscode.MarkdownString('Context-aware Java completion');
					item.range = new vscode.Range(position, position);
					item.sortText = '\u0000';

					return [item];
				} catch (error) {
					console.error('Completion request failed:', error);
					return [];
				}
			}
		},
		'.',
		' ',
		'('
	);

	context.subscriptions.push(explainCmd);
	context.subscriptions.push(addCommentCommand);
	context.subscriptions.push(completionProvider);
}

export function deactivate() {}
