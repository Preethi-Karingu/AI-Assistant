public class Greater {
    public static void main(String[] args) {
    
       int a=10;
       int b=20;

    }
}
 // AI suggestion will appear here